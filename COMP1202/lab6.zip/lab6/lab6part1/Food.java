public abstract class Food {

  String name;

  public Food(String foodName){
    name = foodName;
  }

  public String getName() {
    return name;
  }
}