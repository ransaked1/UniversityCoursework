class Plant extends Food {
	public Plant(String plantName) {
		super(plantName);
	}
}