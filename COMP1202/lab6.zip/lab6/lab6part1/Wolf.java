class Wolf extends Animal {
	public Wolf(String wolfName, Integer wolfAge) {
		super(wolfName, wolfAge);
	}

	public void makeNoise() {
		System.out.println("wooof");
	}
}