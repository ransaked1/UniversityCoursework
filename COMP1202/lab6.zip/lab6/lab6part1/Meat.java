class Meat extends Food {
  public Meat(String meatName) {
    super(meatName);
  }
}
