public abstract class Omnivore extends Animal {}
