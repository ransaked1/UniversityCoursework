public abstract class Herbivore extends Animal {}
