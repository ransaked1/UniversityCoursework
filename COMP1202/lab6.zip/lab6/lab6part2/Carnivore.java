public abstract class Carnivore extends Animal {
}