//Print Hello World!
class Hello {
	/**
	 * Hello world program in Java.
	 *
	 * @param args Standard terminal input.
	 */
	public static void main(String[] args) {
		System.out.println("Hello World!");
	}
}
