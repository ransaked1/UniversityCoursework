package lab4part2;

public class Main {

	public static void main(String[] args) {
		UserGroup userGroup = new UserGroup();
		userGroup.addSampleData();
		userGroup.printUsernames();
	}
}
