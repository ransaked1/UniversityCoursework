public class Train extends Transport {
  public Train(String name) {
    super(name);
  }

  @Override
  public void makeSound() {}

  @Override
  public void setSpeed(int speed) {}
}
