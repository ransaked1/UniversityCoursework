public class JetPlane extends Refuelable {

	public JetPlane(String name, int maxFuelAmount, int fuelAmount) {
		super(name, maxFuelAmount, fuelAmount);
	}

	@Override
	public void makeSound() {
	}

	@Override
	public void setSpeed(int speed) {
	}

	public void takeOff() {
	}

	public void landing() {
	}
}