interface Cycle extends RoadVehicle {
	public void liftFrontWheel();
}