interface RoadVehicle {
	public void drift();
	public void start();
	public void stop();
}